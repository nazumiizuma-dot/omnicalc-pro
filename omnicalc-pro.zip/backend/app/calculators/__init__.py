from importlib import import_module
from pathlib import Path

__all_modules__ = []
_modules_cache = {}

pkg_dir = Path(__file__).resolve().parent
for f in pkg_dir.iterdir():
    if f.suffix == ".py" and f.name not in ("__init__.py", "base.py"):
        name = f.stem
        __all_modules__.append(name)

def load_module(name: str):
    if name in _modules_cache:
        return _modules_cache[name]
    mod = import_module(f"app.calculators.{name}")
    _modules_cache[name] = mod
    return mod

def module_metadata():
    out = {}
    for m in __all_modules__:
        mod = load_module(m)
        out[m] = mod.meta()
    return out
